package com.example.firsthitmonday;



public class MyData {

    static String[] nameArray = {"Jinx", "Vi", "Vander" , "Silco", "Caitlyn", "Jayce", "Mel", "Viktor", "Heimerdinger", "Ekko"};
    static String[] Description = {"1.5", "1.6", "2.0-2.1", "2.2-2.2.3", "2.3-2.3.7", "3.0-3.2.6", "4.0-4.0.4", "4.1-4.3.1", "4.4-4.4.4", "5.0-5.1.1"};

    static Integer[] drawableArray = {R.drawable.jinx, R.drawable.vi, R.drawable.vander,
            R.drawable.silco, R.drawable.caitlyn, R.drawable.jayce, R.drawable.mel,
            R.drawable.viktor, R.drawable.heimerdinger, R.drawable.ekko};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
}
